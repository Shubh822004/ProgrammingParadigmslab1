﻿//First
let rec productTailRec list acc =
    match list with
    | [] -> acc  // Base case: when the list is empty, return the accumulator
    | head :: tail -> productTailRec tail (acc * head)  // Recursive call with the new accumulator

// Usage example
let numbers = [1; 2; 3; 4; 5;6;7]
let result = productTailRec numbers 1  // Start with an initial accumulator value of 1
printfn "Product of all elements: %d" result



//second
let rec recursion n =
    if n <= 1 then
        n
    else
        n * recursion (n - 2)
 
let x = recursion 11
printfn "The product of all odd numbers from a given number to 1 = %A" x



//third
let Names: string list = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]

// Use List.map to trim spaces
let trimmedNames: string list = List.map (fun (name: string) -> name.Trim()) Names

printfn "Trimmed names: %A" trimmedNames



//fourth
// Create a sequence of the first 700 positive integers
let numbers5 = Seq.init 700 (fun i -> i + 1)

// Filter out elements that are multiples of both 7 and 5 (i.e., multiples of 35)
let filteredNumbers = 
    numbers5
    |> Seq.filter (fun x -> x % 35 = 0)  // 35 is the least common multiple of 7 and 5

// Use Seq.fold to sum all the filtered numbers
let sumOfFilteredNumbers = 
    Seq.fold (fun acc x -> acc + x) 0 filteredNumbers

printfn "Sum of numbers that are multiples of both 7 and 5: %d" sumOfFilteredNumbers




//fifth
let names5: string list = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]
let filteredNames = 
    List.filter (fun (name: string) -> name.Contains("I") || name.Contains("i")) names5
let concatenatedNames = 
    match filteredNames with
    | [] -> "" // Handle empty case
    | _ -> List.reduce (fun acc name -> acc + name) filteredNames
printfn "Concatenated names: %s" concatenatedNames